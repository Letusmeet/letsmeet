

module.exports = {
    MONGOURI: 'mongodb+srv://letsmeet:Letsmeetdev-2021@cluster0.7pm0a.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
    JWT_SECRET: 'tysebdfyuydudfuEEEqqahhsyydoosps'
}